# RaceDay — South African Road Event Management System

RaceDay is a full-stack web-based event management platform built specifically for the South African road running, walking, and cycling community.

---

## System Roles

###  Organizer
- Create, edit, and delete events
- Manage event race categories
- Capture and publish participant results
- View all event enrolments

###  Participant
- Register an account and browse upcoming events
- Enter events by selecting race categories
- View personal enrolment history
- Track personal race results and performance

---

##  Part 1 Contents
- `/docs/erd.png` — Entity Relationship Diagram
- `/docs/api-endpoints.md` — REST API Endpoint Specification
- `/docs/raceeday-db.sql` — SQL Server Database Script
- `.github/workflows/ci-cd.yml` — GitHub Actions CI/CD Workflow

---

## ✅ CI/CD Status
https://github.com/Lindokuhle56/RaceDay/commit/c1d68239968355e4daac0a81c1aa621f1a984c

---

##  Power Point Presentation

---

## How to Run the Database
1. Open SQL Server Management Studio (SSMS)
2. Open `docs/raceeday-db.sql`
3. Click **Execute** — database will be created automatically